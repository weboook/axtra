<?php

namespace Livewire\Features\SupportAttributes;

enum AttributeLevel
{
    case ROOT;
    case PROPERTY;
    case METHOD;
}
