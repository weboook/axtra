<?php

namespace Opcodes\LogViewer\Enums;

class FolderSortingMethod
{
    public const Alphabetical = 'Alphabetical';
    public const ModifiedTime = 'ModifiedTime';
}
