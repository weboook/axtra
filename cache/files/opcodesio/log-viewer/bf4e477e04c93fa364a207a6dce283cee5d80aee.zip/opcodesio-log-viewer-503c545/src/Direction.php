<?php

namespace Opcodes\LogViewer;

class Direction
{
    const Forward = 'forward';
    const Backward = 'backward';
}
