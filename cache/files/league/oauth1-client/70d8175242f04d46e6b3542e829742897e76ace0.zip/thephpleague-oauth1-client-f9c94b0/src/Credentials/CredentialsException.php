<?php

namespace League\OAuth1\Client\Credentials;

use Exception;

class CredentialsException extends Exception
{
}
