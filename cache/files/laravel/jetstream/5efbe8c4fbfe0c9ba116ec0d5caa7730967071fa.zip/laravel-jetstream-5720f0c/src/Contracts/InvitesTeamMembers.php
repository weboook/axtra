<?php

namespace Laravel\Jetstream\Contracts;

/**
 * @method void invite(\Illuminate\Foundation\Auth\User $user, \Illuminate\Database\Eloquent\Model $team, string $email, string $role = null)
 */
interface InvitesTeamMembers
{
    //
}
